app.controller('indexController', ['$scope', '$resource', '$location', '$window', '$uibModal', function($scope, $resource, $location, $window, $uibModal) {

    // base restful SERVICE url

}]);

