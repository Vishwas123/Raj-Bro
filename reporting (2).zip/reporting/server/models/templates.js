

// model for mongoose

var mongoose = require('mongoose');

module.exports = mongoose.model('templates', {
	template_name:   	String
});


