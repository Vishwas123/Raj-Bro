var app = angular.module('reportsApp', ['ngResource', 'chart.js']);

