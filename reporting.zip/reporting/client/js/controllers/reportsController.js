app.controller('reportsController', ['$scope', '$resource', '$location', '$window' ,function($scope, $resource, $location, $window) {

	// base restful SERVICE url
	var Report = $resource('/api/reports');

	//initially setting the test ID from the URL data
	//localhost:3000/#/?testid=1&runid=1&duration=360
	var testid 		= $location.search().testid;
	var runid		= $location.search().runid;
	var duration 	= $location.search().duration;


	$scope.testid 	= testid;
	$scope.duration	= duration;
	$scope.runid 	= runid;

	// getting data from the server DB, the results holds the list from the server RESPONSE
	Report.query(function(results) {

		//console.log('query function in client controller');
		//console.log(results);

	});

	$scope.reports =[]

	$scope.addReport = function() {

		var reportsObj = new Report();
		// setting the data to the objects
		reportsObj.testid 			= $scope.testid;
		reportsObj.runid			= $scope.runid;
		reportsObj.duration_time	= $scope.duration;
		reportsObj.total_time		= $scope.total;
		reportsObj.setup_time		= $scope.setup;
		reportsObj.testing_time 	= $scope.testing;
		reportsObj.error_time 		= $scope.error;
		reportsObj.misc_time 		= $scope.misc;
		reportsObj.notes 			= $scope.notes;



		reportsObj.$save(function(result) {
			// JSON got from callback
			// clearing the field
			/*$scope.testid	= '';
			$scope.duration	= '';*/
			$scope.setup	= '';
			$scope.error 	= '';
			$scope.testing 	= '';
			$scope.misc		= '';
			$scope.notes	= '';
			alert("Report Has Been Submitted");
			 

		});


	}
}]);  





