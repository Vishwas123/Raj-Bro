app.controller('avgController', ['$scope', '$resource', '$location', function($scope, $resource, $location) {

    // base restful SERVICE url
    var Report = $resource('avgview/api/reports');

    // array used for populating charts
    var avg_duration = [];
    var avg_total = [];
    var testList = [];

    // initially setting the sortKey to testId
    $scope.sortKey = '_id';

    // this is the sort(keyname) function called in <th> in tableview.html
    // to toggle a switch
    $scope.sort = function(keyname) {
        $scope.sortKey = keyname; //set the sortKey to the param passed
        $scope.reverse = !$scope.reverse; //if true make it false and vice versa
    }

    // getting data from the server DB, the results holds the list from the server RESPONSE
    Report.query(function(results) {

        //console.log('query function in client controller');
        //console.log(results);
        console.log(JSON.stringify(results));
        console.log('results length is ' + results.length);
        $scope.reports = results;


        for (i = results.length - 1; i >= 0; i--) {
            avg_duration.push(results[i].avg_duration);
            avg_total.push(results[i].avg_total);
            testList.push('test : ' + results[i]._id);

        }

    });





    $scope.labels = testList;
    $scope.series = ['AVG_DURATION', 'AVG_TOTAL'];

    $scope.data = [
        avg_duration,
        avg_total
    ];

    $scope.options = {
        title: {
            display: true,
            text: 'Custom Chart Title'
        },
         legend: {
            display: true,
            labels: {
                fontSize: '50'
            }
        },
        maintainAspectRatio: false
    };


    Chart.defaults.global.colours = [
        '#E90808', // red
        '#201BF9' // blue

    ];

     Chart.defaults.global.scaleFontSize = 15;

     Chart.defaults.global.tooltipXPadding= 40;
    







    // data section


}]);
