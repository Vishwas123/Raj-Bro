app.controller('tableController', ['$scope', '$resource', '$location', '$http', function($scope, $resource, $location, $http) {

    var Report = $resource('/tableview/api/reports');
    
    console.log('tableController client');

    // initially setting the sortKey to testId
    $scope.sortKey = 'testid';

    // this is the sort(keyname) function called in <th> in tableview.html
    // to toggle a switch
    $scope.sort = function(keyname) {
        $scope.sortKey = keyname; //set the sortKey to the param passed
        $scope.reverse = !$scope.reverse; //if true make it false and vice versa
    }

    $scope.delete = function(id) {
/*    	$http.put('/deleteReport/').success(function(res) {
    		console.log(res);
    	});*/
    	var deleteReport = $resource('/tableview/api/reports/:id', { id: id});
    	deleteReport.delete();

    };



    Report.query(function(results) {
        console.log('client/tableController query function');
        $scope.reports = results;
    });


}]);
