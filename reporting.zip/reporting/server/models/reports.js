

// model for mongoose

var mongoose = require('mongoose');

module.exports = mongoose.model('reports', {

	testid: 		Number,
	runid: 			Number,
	duration_time: 	Number,
	total_time: 	Number, // this total is Sum of(setup, testing, error, misc) not including duration_time.  
	setup_time: 	Number,
	testing_time: 	Number,
	error_time: 	Number,
	misc_time: 		Number,
	notes: 			String,

})