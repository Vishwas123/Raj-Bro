var Report = require('../models/reports');


module.exports.avgList = function(req, res) {
	console.log('ffff' + JSON.stringify(req.body));
	// get data from MONGOOSE
	Report.aggregate( 
		   [
		     {
		       $group:
		         {
		           _id: "$testid",
		           avg_duration:  { $avg: "$duration_time"   },
		           avg_total: 	  { $avg: "$total_time"		 },		
		           avg_setup:     { $avg: "$setup_time"      },
		           avg_error:     { $avg: "$error_time"      },
		           avg_testing:   { $avg: "$testing_time"    },
		           avg_misc:      { $avg: "$misc_time"       },

		         }
		     }
		   ]
		, function(err, results) {
			//console.log('server/avgController list function');
			//console.log('results in serverside' + JSON.stringify(results));
			res.json(results); 
			
	});
}

