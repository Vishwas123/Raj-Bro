var Report = require('../models/reports');


// By doing exports, this function can be used in other files
module.exports.create = function(req, res) {
	console.log(req.body) // the bodyParser can parse the body from the request
	var report = new Report(req.body);
	report.save(function(err, result) {
		// pass the data to res so that the client can use this
		// This basically is a callback
		console.log("?");
		res.json(result); 
	});
}


module.exports.list = function(req, res) {
	// get data from MONGOOSE
	console.log("list function in server/reportsController");
	
	Report.find({}, function(err, results) {
		res.json(results); 
	});
}


