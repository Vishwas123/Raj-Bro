{

    "testid": 1,
    "runid": 1,
    "duration_time": 10800,
    "total_time": 100000,
    "setup_time": 6000,
    "error_time": 1300,
    "testing_time": 3000,
    "misc_time": 2000,
    "notes": "",
    "__v": 0
}

{

    "testid": 1,
    "runid": 2,
    "duration_time": 10800,
    "setup_time": 6000,
    "error_time": 1300,
    "testing_time": 3000,
    "misc_time": 2000,
    "notes": "",
    "__v": 0
}

{

    "testid": 1,
    "runid": 3,
    "duration_time": 10800,
    "setup_time": 6000,
    "error_time": 500,
    "testing_time": 3000,
    "misc_time": 2000,
    "notes": "",
    "__v": 0
}

{

    "testid": 1,
    "runid": 4,
    "duration_time": 10800,
    "setup_time": 4000,
    "error_time": 5000,
    "testing_time": 1000,
    "misc_time": 2000,
    "notes": "",
    "__v": 0
}

{

    "testid": 1,
    "runid": 5,
    "duration_time": 10800,
    "setup_time": 3000,
    "error_time": 5000,
    "testing_time": 1000,
    "misc_time": 2000,
    "notes": "",
    "__v": 0
}

{

    "testid": 2,
    "runid": 1,
    "duration_time": 8000,
    "setup_time": 6000,
    "error_time": 1789,
    "testing_time": 3000,
    "misc_time": 988,
    "notes": "",
    "__v": 0
}

{

    "testid": 2,
    "runid": 2,
    "duration_time": 13000,
    "setup_time": 7770,
    "error_time": 3330,
    "testing_time": 2543,
    "misc_time": 2000,
    "notes": "",
    "__v": 0
}

{

    "testid": 2,
    "runid": 3,
    "duration_time": 11000,
    "setup_time": 4577,
    "error_time": 1300,
    "testing_time": 5420,
    "misc_time": 2000,
    "notes": "",
    "__v": 0
}

{

    "testid": 2,
    "runid": 4,
    "duration_time": 9500,
    "setup_time": 4475,
    "error_time": 0,
    "testing_time": 5000,
    "misc_time": 0,
    "notes": "",
    "__v": 0
}


{

    "testid": 2,
    "runid": 5,
    "duration_time": 10800,
    "setup_time": 6000,
    "error_time": 1300,
    "testing_time": 5000,
    "misc_time": 2000,
    "notes": "",
    "__v": 0
}

{

    "testid": 3,
    "runid": 1,
    "duration_time": 9500,
    "setup_time": 2000,
    "error_time": 1000,
    "testing_time": 8000,
    "misc_time": 0,
    "notes": "",
    "__v": 0
}

{

    "testid": 3,
    "runid": 2,
    "duration_time": 11000,
    "setup_time": 7641,
    "error_time": 3114,
    "testing_time": 1147,
    "misc_time": 0,
    "notes": "",
    "__v": 0
}

{

    "testid": 3,
    "runid": 3,
    "duration_time": 14000,
    "setup_time": 4577,
    "error_time": 1300,
    "testing_time": 5420,
    "misc_time": 2000,
    "notes": "",
    "__v": 0
}

{

    "testid": 3,
    "runid": 4,
    "duration_time": 9881,
    "setup_time": 5671,
    "error_time": 0,
    "testing_time": 3341,
    "misc_time": 0,
    "notes": "",
    "__v": 0
}

{

    "testid": 3,
    "runid": 5,
    "duration_time": 11014,
    "setup_time": 7881,
    "error_time": 3771,
    "testing_time": 1141,
    "misc_time": 6641,
    "notes": "",
    "__v": 0
}

{

    "testid": 4,
    "runid": 1,
    "duration_time": 10000,
    "setup_time": 3000,
    "error_time": 0,
    "testing_time": 6000,
    "misc_time": 1000,
    "notes": "",
    "__v": 0
}


{

    "testid": 4,
    "runid": 2,
    "duration_time": 14000,
    "setup_time": 4000,
    "error_time": 1000,
    "testing_time": 6000,
    "misc_time": 6641,
    "notes": "",
    "__v": 0
}

{

    "testid": 4,
    "runid": 3,
    "duration_time": 9500,
    "setup_time": 4000,
    "error_time": 0,
    "testing_time": 5000,
    "misc_time": 1000,
    "notes": "",
    "__v": 0
}

{

    "testid": 4,
    "runid": 4,
    "duration_time": 6000,
    "setup_time": 2000,
    "error_time": 3771,
    "testing_time": 7000,
    "misc_time": 0,
    "notes": "",
    "__v": 0
}

{

    "testid": 4,
    "runid": 5,
    "duration_time": 13000,
    "setup_time": 1000,
    "error_time": 0,
    "testing_time": 7000,
    "misc_time": 3000,
    "notes": "",
    "__v": 0
}



