var express 	= require('express'),
	app			= express(),
	bodyParser	= require('body-parser'),
	mongoose	= require('mongoose'),
	reportsController = require('./server/controller/reportsController'),
	tableController = require('./server/controller/tableController'),
	avgController = require('./server/controller/avgController');

	// connection to mongoose
	mongoose.connect('mongodb://localhost:27017/reportsDB'); 


	// declaring the bodyParser
	app.use(bodyParser.urlencoded( { extended: true }));
	app.use(bodyParser.json());

	// the default main page
	app.get('/', function(req, res){
		res.sendFile(__dirname + '/client/views/index.html');
	});


	app.get('/tableview', function(req, res){
		res.sendFile(__dirname + '/client/views/tableview.html');
	});

	app.get('/avgview', function(req, res) {
		res.sendFile(__dirname + '/client/views/avgview.html')
	})


	// doing this to make it easier to write /js  instead of /client/js
	app.use('/js', express.static(__dirname + '/client/js'));

	// POST and GET for the api to save/retrieve data from the DB


	// routes for reportsController
	app.post('/api/reports/', reportsController.create);
	app.get('/api/reports/', reportsController.list);
                                   
    // routes for tableView                                                                                                                                                                                                                                                                                                                                                       
	app.get ('/tableview/api/reports/', tableController.reportList);
	app.post('/tableview/api/reports/', tableController.reportCreate);
	app.delete('/tableview/api/reports/:id', tableController.deleteReport);

	// routes for avgView
	app.get('/avgview/api/reports/', avgController.avgList);
	

	app.listen(3000, function() {
		console.log('I am listening...');
	});

	//app.put('/deleteReport/:id', tableController.deleteReport);
